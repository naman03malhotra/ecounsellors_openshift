-- Status:4:281:MP_0:mark:php:1.24.4::5.5.45:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|ca|75|16384||InnoDB
-- TABLE|color|13|16384||InnoDB
-- TABLE|eic|139|65536||InnoDB
-- TABLE|women|54|16384||InnoDB
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2016-04-18 20:27

--
-- Create Table `ca`
--

DROP TABLE IF EXISTS `ca`;
CREATE TABLE `ca` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `clg` varchar(80) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `ref` varchar(60) NOT NULL,
  `refx` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;

--
-- Data for Table `ca`
--

/*!40000 ALTER TABLE `ca` DISABLE KEYS */;
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('1','Aastha Goel ','goel99aastha@gmail.com','Hansraj college','9871485169','AAS907','https://ecounsellors.in/?lo&ca=AAS907');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('2','Abhishek Nehra','abhinehra1012@gmail.com','Hansraj college','9521651022','ABH792','https://ecounsellors.in/?lo&ca=ABH792');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('3','Aditi Garg ','aditi.garg12@gmail.com ','Hansraj College','9818452617','ADI400','https://ecounsellors.in/?lo&ca=ADI400');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('4','Aditya Dudi','adityabfia@gmail.com','Shaheed sukhdev college of bussiness studies','7827655819','ADI646','https://ecounsellors.in/?lo&ca=ADI646');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('5','Aishwary Khobragade','k.aishwary8@gmail.com','I.I.T. Bombay','9821982231','AIS928','https://ecounsellors.in/?lo&ca=AIS928');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('6','Akshay Singh','singhaks36@gmail.com','Jaypee Institute of Information Technology','8860460842','AKS014','https://ecounsellors.in/?lo&ca=AKS014');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('7','Anant Vashistha','anantseptember17@gmail.com','Indian Institute of Technology , Roorkee','9413993311','ANA472','https://ecounsellors.in/?lo&ca=ANA472');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('8','anisha kumari','kinshukri1996@gmail.com','nit allahabad','9454788294','ANI599','https://ecounsellors.in/?lo&ca=ANI599');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('9','Anjali aggarwal','anjaliagg18@gmail.com','Nsit','9971258827','ANJ587','https://ecounsellors.in/?lo&ca=ANJ587');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('10','Ankita Kumar Nim','Anurj089@gmail.com','Bhai Parmanand Institute of Business Studies','9654708318','ANK515','https://ecounsellors.in/?lo&ca=ANK515');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('11','Ankush Agarwal ','ankush.aggarwal1997@gmail.com ','Keshav Mahavidyalaya ','9810006233','ANK708','https://ecounsellors.in/?lo&ca=ANK708');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('12','Anubhav tiwari','anubhav974t@gmail.com','MNNIT,Allahabad','9454810844','ANU965','https://ecounsellors.in/?lo&ca=ANU965');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('13','D Sri vardhan','srivardhan@live.com','IIT Kharagpur','8106717011','D-S073','https://ecounsellors.in/?lo&ca=D-S073');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('14','Depali','depaliraheja18@gmail.com','Miranda House','7082024991','DEP770','https://ecounsellors.in/?lo&ca=DEP770');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('15','DEVESH SHYNGLE','devesh.shyngle@gmail.com','Northern India Engineering College ','9911191455','DEV394','https://ecounsellors.in/?lo&ca=DEV394');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('16','Divya Nanda','divya4597@gmail.com','Ihm pusa','9560569889','DIV478','https://ecounsellors.in/?lo&ca=DIV478');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('17','Garishma Gulyani','garishmagulyani@hotmail.com','Maitreyi','9868659931','GAR858','https://ecounsellors.in/?lo&ca=GAR858');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('18','Himanshu Garg','himanshu13103432@gmail.com','Jaypee Institute Of Information Technology','9654025272','HIM779','https://ecounsellors.in/?lo&ca=HIM779');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('19','hitesh kumar rathore','hitesh1997rathore@gmail.com','hansraj college','7827096265','HIT836','https://ecounsellors.in/?lo&ca=HIT836');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('20','ISHA GODHWANI','ishagodhwani@gmail.com','Dyal Singh College','9650488039','ISH508','https://ecounsellors.in/?lo&ca=ISH508');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('21','Jagjyot Oberoi','jagjyot@gmail.com','Guru tegh bahadur Institute of technology','85 88 800050','JAG681','https://ecounsellors.in/?lo&ca=JAG681');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('22','Jiten Sardana','jitensardana@gmail.com ','Delhi Technological University','9990074422','JIT137','https://ecounsellors.in/?lo&ca=JIT137');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('23','KISHAN TIWARI','kishantiwari374@gmail.com','MNNIT','9532481243','KIS214','https://ecounsellors.in/?lo&ca=KIS214');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('24','lagan khanna','lagankhanna500@gmail.com','jesus and mary college','8375076813','LAG064','https://ecounsellors.in/?lo&ca=LAG064');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('25','Lagan Munjal','Lagan.munjal11@gmail.com','Dyal singh college','9812368071','LAG252','https://ecounsellors.in/?lo&ca=LAG252');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('26','Mahima Bhagat','mahimabhagat4@gmail.com','Bhai Paramanand Institute of Business Studies','9717401100','MAH799','https://ecounsellors.in/?lo&ca=MAH799');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('27','Mallika Satti','mallikasatti12@gmail.com','Deen Dayal Upadhyaya College,DU','9650487239','MAL264','https://ecounsellors.in/?lo&ca=MAL264');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('28','Mayank Jindal','mayankjindal1996@gmail.com','Delhi Technological University','7838873109','MAY638','https://ecounsellors.in/?lo&ca=MAY638');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('29','Meenal Pant','meenal.pant@ymail.com','Kamala Nehru College,DU','8860239721','MEE349','https://ecounsellors.in/?lo&ca=MEE349');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('30','Mohak Garg','mohak79@gmail.com','Jaypee Institute of Information Technology ','9711118876','MOH739','https://ecounsellors.in/?lo&ca=MOH739');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('31','Namrata sehrawat','namratasehrawat0@gmail.com','Kirorimal college','9654724762','NAM904','https://ecounsellors.in/?lo&ca=NAM904');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('32','Neha Tokas','Nehatokas1997@gmail.com','Jims vk,IPU','9560839863','NEH528','https://ecounsellors.in/?lo&ca=NEH528');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('33','Nikhil Bardia','Iamnikforu@gmail.com ','JIIT','9999946626','NIK646','https://ecounsellors.in/?lo&ca=NIK646');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('34','Nischay','Rocknischay@gmail.com','Sri krishna institute of technology, bangalore','8553603382','NIS316','https://ecounsellors.in/?lo&ca=NIS316');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('35','Nishant Arora','arora.nishant97@gmail.com','Netaji Subhas Institute of Technology','7838767240','NIS232','https://ecounsellors.in/?lo&ca=NIS232');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('36','Nitika','nitika0229@gmail.com','dduc,DU','9671482043','NIT943','https://ecounsellors.in/?lo&ca=NIT943');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('37','Nitika jain','jnitika1610@gmail.com','Hansraj college','9971133548','NIT485','https://ecounsellors.in/?lo&ca=NIT485');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('38','Nitin kumar arora','dr.nitintarika@gmail.com','Jamia Millia Islamia ','9818300782','NIT563','https://ecounsellors.in/?lo&ca=NIT563');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('39','Nitya Shukla','nityashukla85@gmail.com','Shaheed Sukhdev College of Business Studies','9910076626','NIT854','https://ecounsellors.in/?lo&ca=NIT854');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('40','Parminder singh','Parmindersingh8870@gmail.com','Hans raj','8130523072','PAR585','https://ecounsellors.in/?lo&ca=PAR585');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('41','Prabhjot Kaur Sethi ','prabhjotkaur611@gmail.com','Bhaskaracharya college of applied sciences ','9811079703','PRA643','https://ecounsellors.in/?lo&ca=PRA643');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('42','Priyanka Kataria','prnkkataria693@gmail.com','Hansraj College','9711186728','PRI752','https://ecounsellors.in/?lo&ca=PRI752');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('43','Pulkit Chhabra','pulkit.chhabra1995@gmail.com','Jaypee Institute Of Information Technology','8800189698','PUL377','https://ecounsellors.in/?lo&ca=PUL377');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('44','Radhika garg','radhikagarg39@gmail.com ','Mait','9811662750','RAD218','https://ecounsellors.in/?lo&ca=RAD218');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('45','Raghav aggarwal','Raghavaggarwal109@gmail.com','delhi college of arts and commerce','9910463862','RAG428','https://ecounsellors.in/?lo&ca=RAG428');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('46','Rashmi Keshri','rashmi.rashmirocks@gmail.com','Hansraj college','8800710205','RAS547','https://ecounsellors.in/?lo&ca=RAS547');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('47','Rinni Sharma','rinni.online@gmail.com','Kalindi College','9717066190','RIN567','https://ecounsellors.in/?lo&ca=RIN567');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('48','Rishab ','gargrishab18@yahoo.in ','Jiit','9654942994','RIS320','https://ecounsellors.in/?lo&ca=RIS320');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('49','Rukma dangey','rukmadangey@gmail.com ','Jesus and mary ','8130436088','RUK807','https://ecounsellors.in/?lo&ca=RUK807');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('50','Saarthak Jain ','saarthakjain15@gmail.com','Delhi Technological University (formerly Delhi College of Engineering)','9899033663','SAA288','https://ecounsellors.in/?lo&ca=SAA288');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('51','Sahil Thukral','sahilt222@gmail.com','Maharaja agrasen institute of technology ','8447490630','SAH260','https://ecounsellors.in/?lo&ca=SAH260');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('52','Sakshi Arora','sakshiarora188@gmail.com','deen dayal upadhyay college,du','9654917236','SAK392','https://ecounsellors.in/?lo&ca=SAK392');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('53','Sakshi Mittal','Sakshimittal120@gmail.com','Miranda House college','9899675543','SAK369','https://ecounsellors.in/?lo&ca=SAK369');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('54','Sameer Mehta','mehta.sameer96@gmail.com','Thapar Institute of Engg. and Tech. University','7404246768','SAM457','https://ecounsellors.in/?lo&ca=SAM457');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('55','SHASHI RANJAN KUMAR','shashimans@gmail.com','M.N.N.I.T. ALLAHABAD','7233019185','SHA895','https://ecounsellors.in/?lo&ca=SHA895');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('56','Shivam Mahendru','smahendru101@gmail.com','jiit','8527707556','SHI691','https://ecounsellors.in/?lo&ca=SHI691');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('57','Shreya Seth','shreyaseth1996@gmail.com','NSIT','9650929772','SHR905','https://ecounsellors.in/?lo&ca=SHR905');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('58','Simran','Sim.arora2626@gmail.com','Deshbandhu college','7838585309','SIM198','https://ecounsellors.in/?lo&ca=SIM198');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('59','Simran Kaur Bindra','Simran.bindra999@gmail.com','Kamla nehru college','9999292606','SIM470','https://ecounsellors.in/?lo&ca=SIM470');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('60','Soumya ahuja ','soumya.ahuja18@gmail.com','Jesus and mary ','9650260306','SOU211','https://ecounsellors.in/?lo&ca=SOU211');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('61','sourabh gupta','saurav12994@gmail.com','jaypee institute of information technology sec-128 noida','9958043561','SOU585','https://ecounsellors.in/?lo&ca=SOU585');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('62','Srishti Gupta','Lavish.srishti96@gmail.com','Guru tegh bahadur institute of technology','9871395625','SRI343','https://ecounsellors.in/?lo&ca=SRI343');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('63','Surabhi','surabhisinhavn@gmail.com','Deen Dayal Upadhaya College ','8375070432','SUR457','https://ecounsellors.in/?lo&ca=SUR457');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('64','Surbhi Jain','jainsurbhi.9518@gmail.com','Jaypee Institute of Information Technology','8860223540','SUR438','https://ecounsellors.in/?lo&ca=SUR438');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('65','Tanisha Rao','tanisha.yadav5@gmail.com','Jesus and Mary College','9716802302','TAN234','https://ecounsellors.in/?lo&ca=TAN234');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('66','tanya gupta','tanyag330@gmail.com','maharaja agrasen institute of technology','9990675650','TAN232','https://ecounsellors.in/?lo&ca=TAN232');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('67','Unnati Arora','unnatiarora16@gmail.com','Jaypee Institute Of Information Technology, Noida','8130837875','UNN326','https://ecounsellors.in/?lo&ca=UNN326');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('68','varun','9varun2pathak@gmail.com','Maharaja Agrasen institute of technology','7065292702','VAR517','https://ecounsellors.in/?lo&ca=VAR517');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('69','Vikas Kookna','vikaschoudhary102@gmail.com','IIT ROORKEE','7060902287','VIK827','https://ecounsellors.in/?lo&ca=VIK827');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('70','Vivek Kumar','vivkumar263@gmail.com','Hansraj college','9599529615','VIV896','https://ecounsellors.in/?lo&ca=VIV896');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('71','Yashasvi','singla.yashu24@gmail.com','Hansraj College','895989604','YAS630','https://ecounsellors.in/?lo&ca=YAS630');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('72','Yashika Shriwal','yashikashriwal@gmail.com','Kamla Nehru College','7838289844','YAS168','https://ecounsellors.in/?lo&ca=YAS168');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('73','YATISH KAUSHIK','yatish.kaushik742@gmail.com','IIT ROORKEE','8005350922','YAT857','https://ecounsellors.in/?lo&ca=YAT857');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('74','Naman','care@ecounsellors.in','nsit','8979879','NAM333','ASD');
INSERT INTO `ca` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`refx`) VALUES ('75','Mohit','mohitmunjal1907@gmail.com','nsit','978798798','MOH666','aasdas');
/*!40000 ALTER TABLE `ca` ENABLE KEYS */;


--
-- Create Table `color`
--

DROP TABLE IF EXISTS `color`;
CREATE TABLE `color` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `url` text NOT NULL,
  `code` varchar(6) NOT NULL,
  `timestamp` varchar(30) NOT NULL,
  `ip` varchar(30) NOT NULL,
  `agent` varchar(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Data for Table `color`
--

/*!40000 ALTER TABLE `color` DISABLE KEYS */;
INSERT INTO `color` (`id`,`url`,`code`,`timestamp`,`ip`,`agent`) VALUES ('1','https://cdn.filestackcontent.com/w3FyUIKQJmU4CFmVeeTE','','1460232388','178.62.64.106, 141.101.98.181','1');
INSERT INTO `color` (`id`,`url`,`code`,`timestamp`,`ip`,`agent`) VALUES ('2','https://cdn.filestackcontent.com/qe1aWmNQRM6EoHPXzV2v','undefi','1460232508','178.62.64.106, 141.101.98.181','1');
INSERT INTO `color` (`id`,`url`,`code`,`timestamp`,`ip`,`agent`) VALUES ('3','https://cdn.filestackcontent.com/jtEGvYnzRmW02x0TWFPI','NAM333','1460232590','178.62.64.106, 141.101.98.181','1');
INSERT INTO `color` (`id`,`url`,`code`,`timestamp`,`ip`,`agent`) VALUES ('4','https://cdn.filestackcontent.com/kWTwMSpeRpuFPnkyjeh5','PRI528','1460234366','43.225.192.2, 162.158.50.4','1');
INSERT INTO `color` (`id`,`url`,`code`,`timestamp`,`ip`,`agent`) VALUES ('5','https://cdn.filestackcontent.com/F9Y67QOfQc2KRI1RBxbl','SUM999','1460235254','103.48.199.172, 162.158.50.11','1');
INSERT INTO `color` (`id`,`url`,`code`,`timestamp`,`ip`,`agent`) VALUES ('6','https://cdn.filestackcontent.com/sKG20DIjSW28L5xDfJBb','MUK872','1460274326','125.99.184.95, 162.158.50.5','1');
INSERT INTO `color` (`id`,`url`,`code`,`timestamp`,`ip`,`agent`) VALUES ('7','https://cdn.filestackcontent.com/znEiYweT4WS8o6YOsQ2g','MUK872','1460274501','125.99.184.95, 162.158.50.5','1');
INSERT INTO `color` (`id`,`url`,`code`,`timestamp`,`ip`,`agent`) VALUES ('8','https://cdn.filestackcontent.com/mZ3fdJHhS6cdNePSsiyR','SAR696','1460285189','125.99.184.95, 162.158.50.5','1');
INSERT INTO `color` (`id`,`url`,`code`,`timestamp`,`ip`,`agent`) VALUES ('9','https://cdn.filestackcontent.com/ovmaGfOCTqi2qdmeI68K','ANK136','1460333151','117.214.44.101, 162.158.51.209','1');
INSERT INTO `color` (`id`,`url`,`code`,`timestamp`,`ip`,`agent`) VALUES ('10','https://cdn.filestackcontent.com/vUJ3jYrcT9mY01dXORMS','','1460348168','178.62.5.157, 141.101.99.63','1');
INSERT INTO `color` (`id`,`url`,`code`,`timestamp`,`ip`,`agent`) VALUES ('11','https://cdn.filestackcontent.com/e7hZrduhRDaNdc4CuUQd','DHI489','1460348491','122.252.250.252, 162.158.47.12','1');
INSERT INTO `color` (`id`,`url`,`code`,`timestamp`,`ip`,`agent`) VALUES ('12','https://cdn.filestackcontent.com/WGFGC86PRYeFH2vmkA3h','SHU325','1460364867','14.139.238.98, 162.158.47.125','0');
INSERT INTO `color` (`id`,`url`,`code`,`timestamp`,`ip`,`agent`) VALUES ('13','https://cdn.filestackcontent.com/3GfRFnSveCimbEStzDIg','SHU325','1460364913','14.139.238.98, 162.158.47.125','0');
/*!40000 ALTER TABLE `color` ENABLE KEYS */;


--
-- Create Table `eic`
--

DROP TABLE IF EXISTS `eic`;
CREATE TABLE `eic` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `clg` varchar(80) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `ref` varchar(6) NOT NULL,
  `ref_url` text NOT NULL,
  `img_url` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=latin1;

--
-- Data for Table `eic`
--

/*!40000 ALTER TABLE `eic` DISABLE KEYS */;
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('1','Priyanka','priyankamohan1801@gmail.com','Netaji Subhas Institute of Technology','9711958890','PRI528','https://ecounsellors.in/?lo&eic=PRI528','https://ecounsellors.in/color-yourself/?eic=PRI528');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('2','Gaurav tanwar','gauravtanwar125@gmail.com','Nsit','9716003314','GAU273','https://ecounsellors.in/?lo&eic=GAU273','https://ecounsellors.in/color-yourself/?eic=GAU273');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('3','Mridul Babbar','mridulbabbar1@Gmail.com','JIMS ( ip university )','9999993266','MRI688','https://ecounsellors.in/?lo&eic=MRI688','https://ecounsellors.in/color-yourself/?eic=MRI688');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('4','Nitish Laipubam','nitish.laipubam@live.com','Zakir Hussain Delhi College','8285484354','NIT181','https://ecounsellors.in/?lo&eic=NIT181','https://ecounsellors.in/color-yourself/?eic=NIT181');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('5','Shivam garg','Shivamgarg96@gmail.com','Nsit','7087733428','SHI941','https://ecounsellors.in/?lo&eic=SHI941','https://ecounsellors.in/color-yourself/?eic=SHI941');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('6','Saksham Goel ','saksham171194@gmail.com','NMIMS ','7840059997','SAK258','https://ecounsellors.in/?lo&eic=SAK258','https://ecounsellors.in/color-yourself/?eic=SAK258');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('7','Amogh Hassija','amogh97@gmail.com','Netaji Subhas Institute of Technology','8447493931','AMO980','https://ecounsellors.in/?lo&eic=AMO980','https://ecounsellors.in/color-yourself/?eic=AMO980');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('8','Ankit Sharma','ankitsharma6813@gmail.com','Jaypee institute of Information Technology','9971884212','ANK071','https://ecounsellors.in/?lo&eic=ANK071','https://ecounsellors.in/color-yourself/?eic=ANK071');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('9','Mukul','mukulgta7@gmail.com','Netaji subhas institute of technology','9560611754','MUK872','https://ecounsellors.in/?lo&eic=MUK872','https://ecounsellors.in/color-yourself/?eic=MUK872');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('10','swati singh','swati_151996@yahoo.com','netaji subhas institute of technology','9711958072','SWA445','https://ecounsellors.in/?lo&eic=SWA445','https://ecounsellors.in/color-yourself/?eic=SWA445');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('11','Kirti','kmspalam@gmail.com','NSIT','9717713776','KIR116','https://ecounsellors.in/?lo&eic=KIR116','https://ecounsellors.in/color-yourself/?eic=KIR116');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('12','Aashna Mittal ','aashna.mittal27@gmail.com','Indira Gandhi Delhi Technical University For Women ','7042720248','AAS591','https://ecounsellors.in/?lo&eic=AAS591','https://ecounsellors.in/color-yourself/?eic=AAS591');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('13','Jaskeerat kaur','Jaskeeratkaurkalra@gmail.com','IGDTUW','8447730320','JAS010','https://ecounsellors.in/?lo&eic=JAS010','https://ecounsellors.in/color-yourself/?eic=JAS010');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('14','Mehak Mittal','mehak15597@gmail.com','Bvimr','9811312282','MEH038','https://ecounsellors.in/?lo&eic=MEH038','https://ecounsellors.in/color-yourself/?eic=MEH038');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('15','Sukanya Kapoor','kapsukanya@gmail.com','NSIT','8375096863','SUK059','https://ecounsellors.in/?lo&eic=SUK059','https://ecounsellors.in/color-yourself/?eic=SUK059');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('16','Mehak','mehaksahni093@gmail.com','Institute of home economics','9999442065','MEH213','https://ecounsellors.in/?lo&eic=MEH213','https://ecounsellors.in/color-yourself/?eic=MEH213');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('17','Sarah Jawaid','sarah_jawaid03@yahoo.com','Indira Gandhi Delhi Technical University for Women','8447635885','SAR436','https://ecounsellors.in/?lo&eic=SAR436','https://ecounsellors.in/color-yourself/?eic=SAR436');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('18','Nayan Sayare','nayansayare@gmail.com','NSIT','9911042793','NAY936','https://ecounsellors.in/?lo&eic=NAY936','https://ecounsellors.in/color-yourself/?eic=NAY936');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('19','Mukul Dutt','mkldutt@gmail.com','NSIT','9871075256','MUK459','https://ecounsellors.in/?lo&eic=MUK459','https://ecounsellors.in/color-yourself/?eic=MUK459');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('20','Mishtha Wadhwa','mishthawadhwa@gmail.com','IMT','9811861183','MIS030','https://ecounsellors.in/?lo&eic=MIS030','https://ecounsellors.in/color-yourself/?eic=MIS030');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('21','Danish Muhammed Shah','danishshahhh@gmail.con','National Institute of Technology, Srinagar','9469778673','DAN632','https://ecounsellors.in/?lo&eic=DAN632','https://ecounsellors.in/color-yourself/?eic=DAN632');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('22','shubham bansal','shubhambansal526@gmail.com','deen dayal upadhayaya','9999253054','SHU353','https://ecounsellors.in/?lo&eic=SHU353','https://ecounsellors.in/color-yourself/?eic=SHU353');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('23','Shikhar Pahadia ','shikhar16pahadia@gmail.com ','Netaji Subhas Institute of Technology ','9638841627','SHI596','https://ecounsellors.in/?lo&eic=SHI596','https://ecounsellors.in/color-yourself/?eic=SHI596');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('24','Siddharth Harsh','sidharsh503@gmail.com','BSAITM Faridabad','8527313764','SID621','https://ecounsellors.in/?lo&eic=SID621','https://ecounsellors.in/color-yourself/?eic=SID621');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('25','Palak Bansal','Plkbansal15@gmail.com','Lady Shri Ram College for Women','8607991049','PAL450','https://ecounsellors.in/?lo&eic=PAL450','https://ecounsellors.in/color-yourself/?eic=PAL450');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('26','Ayush Singhal','ayushsinghal2335@gmail.com','Indian Institute of Technology, Delhi','+918527380499','AYU988','https://ecounsellors.in/?lo&eic=AYU988','https://ecounsellors.in/color-yourself/?eic=AYU988');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('27','Radhika Shah','radhikashah.rs@gmail.com','Lady Shri Ram College for Women','7838038923','RAD296','https://ecounsellors.in/?lo&eic=RAD296','https://ecounsellors.in/color-yourself/?eic=RAD296');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('28','Jyoti aggarwal','agjyoti191@gmail. com','Nsit','8285351333','JYO448','https://ecounsellors.in/?lo&eic=JYO448','https://ecounsellors.in/color-yourself/?eic=JYO448');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('29','Narender','nsaini4luv@gmail.com','Ramjas college','9999389924','NAR865','https://ecounsellors.in/?lo&eic=NAR865','https://ecounsellors.in/color-yourself/?eic=NAR865');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('30','Vineet','vbawa61@gmail.com','Ymca ','9818683840','VIN284','https://ecounsellors.in/?lo&eic=VIN284','https://ecounsellors.in/color-yourself/?eic=VIN284');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('31','Rushil Sareen ','Rushil.bbasep15020@spjain.org ','S P Jain School of Global Management ','+65 81178172 ','RUS059','https://ecounsellors.in/?lo&eic=RUS059','https://ecounsellors.in/color-yourself/?eic=RUS059');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('32','Archit Aggarwal ','archit522@gmail.com ','IIT Delhi','9560939391','ARC385','https://ecounsellors.in/?lo&eic=ARC385','https://ecounsellors.in/color-yourself/?eic=ARC385');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('33','Lokesh Lalwani','lokeshlalwani19@gmail.com','Manipal university jaipur','7568920158','LOK386','https://ecounsellors.in/?lo&eic=LOK386','https://ecounsellors.in/color-yourself/?eic=LOK386');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('34','Siddharth Arora','Siddarora@hotmail.com','MRCE','9911615839','SID835','https://ecounsellors.in/?lo&eic=SID835','https://ecounsellors.in/color-yourself/?eic=SID835');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('35','Jaskirat ','Jaskiratsahni521@gmail.com','Maharaja surajmal institute (IPU)','9999772668','JAS355','https://ecounsellors.in/?lo&eic=JAS355','https://ecounsellors.in/color-yourself/?eic=JAS355');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('36','Rahul Kansal','rk.kansal@yahoo.com','Hansraj','8447794085','RAH546','https://ecounsellors.in/?lo&eic=RAH546','https://ecounsellors.in/color-yourself/?eic=RAH546');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('37','Divesh bhardwaj','devbhardwaj2feb@gmail.com','YMCA UST FARIDABAD','9210022367','DIV215','https://ecounsellors.in/?lo&eic=DIV215','https://ecounsellors.in/color-yourself/?eic=DIV215');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('38','Nancy Jain','nancy8897@gmail.com','IGDTUW ','9910820992','NAN470','https://ecounsellors.in/?lo&eic=NAN470','https://ecounsellors.in/color-yourself/?eic=NAN470');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('39','Rishabh Goel','rishab11.goel@gmail.com','YMCAUST of science and technology, Faridabad','9582980748','RIS835','https://ecounsellors.in/?lo&eic=RIS835','https://ecounsellors.in/color-yourself/?eic=RIS835');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('40','Aditya Garg','f2015618@pilani.bits-pilani.ac.in','BITS Pilani','7727916127','ADI189','https://ecounsellors.in/?lo&eic=ADI189','https://ecounsellors.in/color-yourself/?eic=ADI189');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('41','Rashmi','rashmi.s268@gmail.com','Bharati College','8527667519','RAS993','https://ecounsellors.in/?lo&eic=RAS993','https://ecounsellors.in/color-yourself/?eic=RAS993');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('42','anuditt jain','avi.lucifer97@gmail.com','nsit ','9711464407','ANU929','https://ecounsellors.in/?lo&eic=ANU929','https://ecounsellors.in/color-yourself/?eic=ANU929');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('43','Himanshu Attri','attri.him@gmail.com','NSIT','9718961689','HIM364','https://ecounsellors.in/?lo&eic=HIM364','https://ecounsellors.in/color-yourself/?eic=HIM364');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('44','Utkarsh Tyagi','utyagi1234@gmail.com','NSIT','8468953909','UTK081','https://ecounsellors.in/?lo&eic=UTK081','https://ecounsellors.in/color-yourself/?eic=UTK081');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('45','Mohit anand','f2015752@pilani.bits-pilani.ac.in','Bits pilani','9983090691','MOH195','https://ecounsellors.in/?lo&eic=MOH195','https://ecounsellors.in/color-yourself/?eic=MOH195');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('46','Divyanshu','querty.07@gmail.com','NSIT','9650829461','DIV552','https://ecounsellors.in/?lo&eic=DIV552','https://ecounsellors.in/color-yourself/?eic=DIV552');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('47','AMAN KHULLAR','amankhullar09@gmail.com','NATIONAL INSTITUTE OF TECHNOLOGY,JAMSHEDPUR','7543885474','AMA690','https://ecounsellors.in/?lo&eic=AMA690','https://ecounsellors.in/color-yourself/?eic=AMA690');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('48','Neha Anand','nehaanandsat14@gmail.com','Amity School of Engineering & Technology','9718963847','NEH623','https://ecounsellors.in/?lo&eic=NEH623','https://ecounsellors.in/color-yourself/?eic=NEH623');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('49','Yashika','123yashikasaini@gmail.com','NSIT','9599275117','YAS789','https://ecounsellors.in/?lo&eic=YAS789','https://ecounsellors.in/color-yourself/?eic=YAS789');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('50','R. Sagarika','richa_sagarika@yahoo.in','Motilal Nehru College, Delhi University','8826521318','R.-026','https://ecounsellors.in/?lo&eic=R.-026','https://ecounsellors.in/color-yourself/?eic=R.-026');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('51','Sarabjeet singh','singhsarabjeet997@gmail.com','Guru tegh bahadur institute of technology','8860891597','SAR100','https://ecounsellors.in/?lo&eic=SAR100','https://ecounsellors.in/color-yourself/?eic=SAR100');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('52','VAIBHAV GUPTA','HELLOEVERYONE1997@GMAIL.COM','SHYAM LAL COLLEGE','9871516414','VAI854','https://ecounsellors.in/?lo&eic=VAI854','https://ecounsellors.in/color-yourself/?eic=VAI854');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('53','Arshiya Gahlot','arshiya.ghlt@gmail.com','Netaji Subhas Institute of Technology','9910802937','ARS650','https://ecounsellors.in/?lo&eic=ARS650','https://ecounsellors.in/color-yourself/?eic=ARS650');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('54','Parth bhardwaj','parths5316@gmail.com','Shyaam lal college(m)','7041441194','PAR575','https://ecounsellors.in/?lo&eic=PAR575','https://ecounsellors.in/color-yourself/?eic=PAR575');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('55','Anushka tripathi','tripathi.anushka 49@gmail.com','Daulat ram college, DU','7838554135','ANU623','https://ecounsellors.in/?lo&eic=ANU623','https://ecounsellors.in/color-yourself/?eic=ANU623');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('56','GULAM GHAUS USMANI','gulambit@gmail.com','NIT JAMSHEDPUR','8797595410','GUL234','https://ecounsellors.in/?lo&eic=GUL234','https://ecounsellors.in/color-yourself/?eic=GUL234');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('57','Tahir ahmad ','Ttahir330@gmail.com','Nit ','9906436328','TAH299','https://ecounsellors.in/?lo&eic=TAH299','https://ecounsellors.in/color-yourself/?eic=TAH299');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('58','Vinod','vinodkakran1@gmail.com','RLA E','9811250897','VIN926','https://ecounsellors.in/?lo&eic=VIN926','https://ecounsellors.in/color-yourself/?eic=VIN926');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('59','Achintya Sarkar','sarkarachin@gmail.com','Bhagwan Purshuram Institute of Technology','9717868078','ACH213','https://ecounsellors.in/?lo&eic=ACH213','https://ecounsellors.in/color-yourself/?eic=ACH213');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('60','Abhishek jain','abhi.jain0124@gma.com','Bpit','8744003489','ABH407','https://ecounsellors.in/?lo&eic=ABH407','https://ecounsellors.in/color-yourself/?eic=ABH407');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('61','Niharika Arora','niharikaarora1997@gmail.com','BPIT','8826668920','NIH197','https://ecounsellors.in/?lo&eic=NIH197','https://ecounsellors.in/color-yourself/?eic=NIH197');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('62','Subhadeep Halder','itsmesubhadeep@gmail.com','Sri Venkateshwara College','9953490132','SUB135','https://ecounsellors.in/?lo&eic=SUB135','https://ecounsellors.in/color-yourself/?eic=SUB135');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('63','bazil ahmed','rahulayu.6@gmail.com','usict','9971877867','BAZ275','https://ecounsellors.in/?lo&eic=BAZ275','https://ecounsellors.in/color-yourself/?eic=BAZ275');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('64','arushis sharma','arushisharma450@gmail.com','deen dayal upadhyaya college','9716228102','ARU959','https://ecounsellors.in/?lo&eic=ARU959','https://ecounsellors.in/color-yourself/?eic=ARU959');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('65','akash','akash1994kasyap@gmail.com','shri venketeswara college','9650848392','AKA528','https://ecounsellors.in/?lo&eic=AKA528','https://ecounsellors.in/color-yourself/?eic=AKA528');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('66','Divija Gupta','divijagupta7@gmail.com','Bhagwan Parshuram Institute of Technology','9810086492','DIV350','https://ecounsellors.in/?lo&eic=DIV350','https://ecounsellors.in/color-yourself/?eic=DIV350');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('67','AVINASH TIWARI','tavinash541@gmail.com','SWAMI SHRADDHANAND COLLEGE','9716628373','AVI445','https://ecounsellors.in/?lo&eic=AVI445','https://ecounsellors.in/color-yourself/?eic=AVI445');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('68','SHIVAM','shivamgupta354@gmail.com','GB PANT ENGINEERING COLLEGE NEW DELHI','9871230725','SHI183','https://ecounsellors.in/?lo&eic=SHI183','https://ecounsellors.in/color-yourself/?eic=SHI183');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('69','zahid rashid malik','xahieedmalik49@gmail.com','NIT Srinagar','7827080407','ZAH547','https://ecounsellors.in/?lo&eic=ZAH547','https://ecounsellors.in/color-yourself/?eic=ZAH547');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('70','Nasir Mushtaq Bhat','adilbhat1994@rediffmail.com','NIT Srinagar','9622895118','NAS342','https://ecounsellors.in/?lo&eic=NAS342','https://ecounsellors.in/color-yourself/?eic=NAS342');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('71','sagar','sagarrrr18 @gmail.com','swami shraddhanand college','8527032358','SAG833','https://ecounsellors.in/?lo&eic=SAG833','https://ecounsellors.in/color-yourself/?eic=SAG833');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('72','Atul Kumar','aksiit1992@gmail.com','MAIT','8860092622','ATU894','https://ecounsellors.in/?lo&eic=ATU894','https://ecounsellors.in/color-yourself/?eic=ATU894');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('73','PIYUSH CHHABRA','piyushchhabrarockz@gmail.com','MANAV RACHNA INTERNATIONAL UNIVERSITY','9654936222','PIY796','https://ecounsellors.in/?lo&eic=PIY796','https://ecounsellors.in/color-yourself/?eic=PIY796');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('74','ANJALI GAIROLA','anjaligairola08@gmail.com','IGDTUW','8800923094','ANJ951','https://ecounsellors.in/?lo&eic=ANJ951','https://ecounsellors.in/color-yourself/?eic=ANJ951');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('75','DHIRAJ KUMAR MISHRA','dhirajmishra0301@gmail.com','NIT JAMSHEFPUR','9905157632','DHI489','https://ecounsellors.in/?lo&eic=DHI489','https://ecounsellors.in/color-yourself/?eic=DHI489');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('76','Anket Ghosh','anket.ghosh1995@gmail.com','NIT JAMSHEDPUR','7856858527','ANK136','https://ecounsellors.in/?lo&eic=ANK136','https://ecounsellors.in/color-yourself/?eic=ANK136');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('77','Nikhil Singh ','nikhilsingh9999@outlook.com','Sri Venkateswara College ','9599929215','NIK129','https://ecounsellors.in/?lo&eic=NIK129','https://ecounsellors.in/color-yourself/?eic=NIK129');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('78','vipasha','vipashadhiman11@gmail.com','IGDTUW','7531043938','VIP980','https://ecounsellors.in/?lo&eic=VIP980','https://ecounsellors.in/color-yourself/?eic=VIP980');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('79','Yatharth Yadav','yadavyatharth98@gmail.com','NSIT','9013572044','YAT370','https://ecounsellors.in/?lo&eic=YAT370','https://ecounsellors.in/color-yourself/?eic=YAT370');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('80','Ramandeep singh','ramandeep_siali@yahoo.co.in','Sri Guru Nanak Dev Khalsa College','9013014541','RAM663','https://ecounsellors.in/?lo&eic=RAM663','https://ecounsellors.in/color-yourself/?eic=RAM663');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('81','Shanvi Kukreti ','kukretishanvi@gmail.com','NSIT','9958306828','SHA026','https://ecounsellors.in/?lo&eic=SHA026','https://ecounsellors.in/color-yourself/?eic=SHA026');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('82','Ayush Bansal','itsayushbansal@gmail.com','JIIT','8130544394','AYU318','https://ecounsellors.in/?lo&eic=AYU318','https://ecounsellors.in/color-yourself/?eic=AYU318');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('83','Garima Chadha','garimachadha95@gmail.com','NSIT','9555752709','GAR072','https://ecounsellors.in/?lo&eic=GAR072','https://ecounsellors.in/color-yourself/?eic=GAR072');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('84','Rakshit Raj','rajanrakshit99@gmail.com','DTU','7042146489','RAK073','https://ecounsellors.in/?lo&eic=RAK073','https://ecounsellors.in/color-yourself/?eic=RAK073');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('85','Sumit Kumar','sumitkumar024nsit@gmail.com','Nsit','9958288964','SUM749','https://ecounsellors.in/?lo&eic=SUM749','https://ecounsellors.in/color-yourself/?eic=SUM749');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('86','Udit Thukral','uditthukral@gmail.com','PGDAV','7042653362','UDI587','https://ecounsellors.in/?lo&eic=UDI587','https://ecounsellors.in/color-yourself/?eic=UDI587');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('87','Ayusha maken','ayushamaken97@gmail.com','BVIMR , new delhi','7042269273','AYU872','https://ecounsellors.in/?lo&eic=AYU872','https://ecounsellors.in/color-yourself/?eic=AYU872');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('88','Sidhant chetal','sidhantchetal@gmail.com','NSIT','8447407818','SID130','https://ecounsellors.in/?lo&eic=SID130','https://ecounsellors.in/color-yourself/?eic=SID130');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('89','Ajay Lather ','ajaylather2050@gmail.com ','Netaji Subhas Institute of Technology ','8802584435','AJA609','https://ecounsellors.in/?lo&eic=AJA609','https://ecounsellors.in/color-yourself/?eic=AJA609');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('90','karan kapooria','karankapooria10@gmail.com','AIACTR','9643906025','KAR822','https://ecounsellors.in/?lo&eic=KAR822','https://ecounsellors.in/color-yourself/?eic=KAR822');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('91','saransh datyal','saranshdatyal29@gmail.com','Maharaja Agrasen Institute of Technology','9650240287','SAR696','https://ecounsellors.in/?lo&eic=SAR696','https://ecounsellors.in/color-yourself/?eic=SAR696');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('92','sandeep shekhar','sandeepiit1510@gmail.com','mnnit allahabad','7080148375','SAN584','https://ecounsellors.in/?lo&eic=SAN584','https://ecounsellors.in/color-yourself/?eic=SAN584');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('93','Surendra Singh Jayant','gk2595349@gmail.com','NIT Allahabad','7704874507','SUR493','https://ecounsellors.in/?lo&eic=SUR493','https://ecounsellors.in/color-yourself/?eic=SUR493');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('94','Prashant sharma','Prashant.sharma.pacific@gmail.com','Apeejay stya university','9996058977','PRA625','https://ecounsellors.in/?lo&eic=PRA625','https://ecounsellors.in/color-yourself/?eic=PRA625');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('95','Aarushi Arora','aaarishi6@gmail.com','Bharati college','9654024720','AAR239','https://ecounsellors.in/?lo&eic=AAR239','https://ecounsellors.in/color-yourself/?eic=AAR239');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('96','Utkarsh','utkarshaggarwal33@gmail.com','Dtu','9711208363','UTK120','https://ecounsellors.in/?lo&eic=UTK120','https://ecounsellors.in/color-yourself/?eic=UTK120');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('97','Anadil Faridy','fightrelegion@gmail.com','NSIT','9899291736','ANA101','https://ecounsellors.in/?lo&eic=ANA101','https://ecounsellors.in/color-yourself/?eic=ANA101');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('98','Ankush Aggarwal','ankushaggarwal786@gmail.com','kcc institute of technology and management ','9015594506','ANK735','https://ecounsellors.in/?lo&eic=ANK735','https://ecounsellors.in/color-yourself/?eic=ANK735');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('99','Simra','simra.afreen@yahoo.com','Nsit','8010416414','SIM113','https://ecounsellors.in/?lo&eic=SIM113','https://ecounsellors.in/color-yourself/?eic=SIM113');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('100','PARAN MALHOTRA','paranmalhotra01@gmail.com','NSIT','8447053939','PAR231','https://ecounsellors.in/?lo&eic=PAR231','https://ecounsellors.in/color-yourself/?eic=PAR231');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('101','Twinkle Soni','twinklesoni1994@gmail.com','Asian Accademy of Media Studies','7838611414','TWI985','https://ecounsellors.in/?lo&eic=TWI985','https://ecounsellors.in/color-yourself/?eic=TWI985');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('102','Janmjay ','janmjay1111@yahoo.co.in','Maharaja Surajmal Institute of Technology ','9582130213','JAN458','https://ecounsellors.in/?lo&eic=JAN458','https://ecounsellors.in/color-yourself/?eic=JAN458');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('103','Shubham','Shubham.garg708@gmail.com','KCCITM','9999454001','SHU767','https://ecounsellors.in/?lo&eic=SHU767','https://ecounsellors.in/color-yourself/?eic=SHU767');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('104','Ashia Monachan','ashiamonachan95@gamil.com','kccitm','9990170582','ASH241','https://ecounsellors.in/?lo&eic=ASH241','https://ecounsellors.in/color-yourself/?eic=ASH241');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('105','Himalay Agarwal','agarwalhimalay@gmail.com','KCCITM','8447166226','HIM235','https://ecounsellors.in/?lo&eic=HIM235','https://ecounsellors.in/color-yourself/?eic=HIM235');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('106','Rishab Goel','rishab1goel@gmail.com','MAIT','9999889622','RIS577','https://ecounsellors.in/?lo&eic=RIS577','https://ecounsellors.in/color-yourself/?eic=RIS577');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('107','Lovish Mittal','lovishmittal21@gmail.com','jaypee institute of information technology','8285613251','LOV480','https://ecounsellors.in/?lo&eic=LOV480','https://ecounsellors.in/color-yourself/?eic=LOV480');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('108','Angela gupta','angelagupta95@gmail.com','KCC institute of technology and management','9811280905','ANG334','https://ecounsellors.in/?lo&eic=ANG334','https://ecounsellors.in/color-yourself/?eic=ANG334');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('109','Nikhil','nnniks830@gmail.com','Kcc institute of technology and management','8826556949','NIK147','https://ecounsellors.in/?lo&eic=NIK147','https://ecounsellors.in/color-yourself/?eic=NIK147');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('110','Ankita panwar','Ankupanwar23oct@gmail.com','Nit,jamshedpur','7838083971','ANK652','https://ecounsellors.in/?lo&eic=ANK652','https://ecounsellors.in/color-yourself/?eic=ANK652');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('111','Samarth seth','Sethsamarth9@gmail.com','Kccitm','9654189206','SAM402','https://ecounsellors.in/?lo&eic=SAM402','https://ecounsellors.in/color-yourself/?eic=SAM402');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('112','Ankit Rana','ankitrana.95@outlook.com','KCC ITM','8860181294','ANK478','https://ecounsellors.in/?lo&eic=ANK478','https://ecounsellors.in/color-yourself/?eic=ANK478');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('113','Nirmit Goyal','nirmitgoyal.goyal@gmail.com','Jaypee Institute of Information Technology','+918447620955','NIR680','https://ecounsellors.in/?lo&eic=NIR680','https://ecounsellors.in/color-yourself/?eic=NIR680');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('114','avadh naresh kushwaha','avadhkcc@gmail.com','kccitm','9013773611','AVA273','https://ecounsellors.in/?lo&eic=AVA273','https://ecounsellors.in/color-yourself/?eic=AVA273');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('115','Shantanu Indoria','shanphelps005@gmail.com','Netaji Subhas Institute of Technology, New Delhi','8130243555','SHA700','https://ecounsellors.in/?lo&eic=SHA700','https://ecounsellors.in/color-yourself/?eic=SHA700');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('116','Nishant Arora','arora.nishant97@gmail.com','Netaji Subhas Institute of Technology','7838767240','NIS521','https://ecounsellors.in/?lo&eic=NIS521','https://ecounsellors.in/color-yourself/?eic=NIS521');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('117','vijay tiwari','vijaytiwari786@hotmail.com','kccitm','9451125126','VIJ756','https://ecounsellors.in/?lo&eic=VIJ756','https://ecounsellors.in/color-yourself/?eic=VIJ756');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('118','Ramanjeet Kaur','aries.ramanjeet95@gmail.com','GTBIT,IP University','9971045658','RAM927','https://ecounsellors.in/?lo&eic=RAM927','https://ecounsellors.in/color-yourself/?eic=RAM927');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('119','dipu kumar','dipusinghrana98@gmail.com','KCCITM','9899221843','DIP394','https://ecounsellors.in/?lo&eic=DIP394','https://ecounsellors.in/color-yourself/?eic=DIP394');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('120','khushboo','khushboo32k@gmail.com','kcc itm','8527834401','KHU097','https://ecounsellors.in/?lo&eic=KHU097','https://ecounsellors.in/color-yourself/?eic=KHU097');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('121','DISHA SINGH','dish_singh_28@yahoo.com','KCC INSTITUTE OF TECHNOLOGY AND MANAGEMENT','9560401723','DIS213','https://ecounsellors.in/?lo&eic=DIS213','https://ecounsellors.in/color-yourself/?eic=DIS213');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('122','SHUBHAM KUMAR','shubham.kr9195@gmail.com','KCC INSTITUTE OF TECHNOLOGY AND MANAGEMENT','9650227140','SHU021','https://ecounsellors.in/?lo&eic=SHU021','https://ecounsellors.in/color-yourself/?eic=SHU021');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('123','Poornima','poonam300796@gmail.com','hansraj, Delhi University','8860086803','POO391','https://ecounsellors.in/?lo&eic=POO391','https://ecounsellors.in/color-yourself/?eic=POO391');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('124','Arjun Arora','aroraarjun1996@gmail.com','MSIT','8010829301','ARJ222','https://ecounsellors.in/?lo&eic=ARJ222','https://ecounsellors.in/color-yourself/?eic=ARJ222');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('125','Rishabh Maheshwari','maheshwari.rishabh11@gmail.com','Maharaja Agrasen Institute of Technology','9560673614','RIS714','https://ecounsellors.in/?lo&eic=RIS714','https://ecounsellors.in/color-yourself/?eic=RIS714');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('126','Shubham Pahwa','shubham.pahwa1414@gmail.com','Jaypee Institute of Information Technology','9643133047','SHU325','https://ecounsellors.in/?lo&eic=SHU325','https://ecounsellors.in/color-yourself/?eic=SHU325');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('127','Naman Singhal','nsinghal332@gmail.com','Jaypee institute of information technology','9639269141','NAM039','https://ecounsellors.in/?lo&eic=NAM039','https://ecounsellors.in/color-yourself/?eic=NAM039');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('128','Palak Gupta','palak_gupta2596@yahoo.co.in','Jaypee University of Engineering and Technology, Guna','9179271445','PAL083','https://ecounsellors.in/?lo&eic=PAL083','https://ecounsellors.in/color-yourself/?eic=PAL083');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('129','Sanket Chaturvedi','sanket.champ21@gmail.com','Jaypee Institute of Information Technology','8130032476','SAN020','https://ecounsellors.in/?lo&eic=SAN020','https://ecounsellors.in/color-yourself/?eic=SAN020');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('130','swapnil gupta ','swapnilgupta154@gmail.com ','Jaypee institute of information technology ','8130816300','SWA581','https://ecounsellors.in/?lo&eic=SWA581','https://ecounsellors.in/color-yourself/?eic=SWA581');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('131','Shubham sharma','Shubham1646@yahoo.in','Jaypee institute of informstion and technology ','9871144174','SHU003','https://ecounsellors.in/?lo&eic=SHU003','https://ecounsellors.in/color-yourself/?eic=SHU003');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('132','Krishan Gupta','krishangupta30@yahoo.com','Jaypee Institute Of Information Technology,Noida','9013537909','KRI141','https://ecounsellors.in/?lo&eic=KRI141','https://ecounsellors.in/color-yourself/?eic=KRI141');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('133','Tamanpreet Kaur','tamanpreetkaur81@gmail.com','Vivekananda Institute of Professional Studies','7042268080','TAM334','https://ecounsellors.in/?lo&eic=TAM334','https://ecounsellors.in/color-yourself/?eic=TAM334');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('134','Abhinav Vijayvergiya','vijayvergiya.abhinav007@gmail.com','JIIT ','9654313570','ABH029','https://ecounsellors.in/?lo&eic=ABH029','https://ecounsellors.in/color-yourself/?eic=ABH029');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('135','Kumar Smit','kumarsmit1996@gmail.com','Ramjas College','9643792017','KUM299','https://ecounsellors.in/?lo&eic=KUM299','https://ecounsellors.in/color-yourself/?eic=KUM299');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('136','Neha','neha66666.ng@gmail.com','KCC institute of technology and management','9711234349','NEH803','https://ecounsellors.in/?lo&eic=NEH803','https://ecounsellors.in/color-yourself/?eic=NEH803');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('137','hardik gupta','f2013435@pilani.bits-pilani.ac.in','bits pilani','8852065999','HAR810','https://ecounsellors.in/?lo&eic=HAR810','https://ecounsellors.in/color-yourself/?eic=HAR810');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('138','Prakhar Srivastava','prakharsrivastava002@gmail.com','JIIT SEC-62','9971630896','PRA141','https://ecounsellors.in/?lo&eic=PRA141','https://ecounsellors.in/color-yourself/?eic=PRA141');
INSERT INTO `eic` (`id`,`name`,`email`,`clg`,`phone`,`ref`,`ref_url`,`img_url`) VALUES ('139','Sumit','sumit.ecounsellors@gmail.com','NSIT','008098098','SUM999','','');
/*!40000 ALTER TABLE `eic` ENABLE KEYS */;


--
-- Create Table `women`
--

DROP TABLE IF EXISTS `women`;
CREATE TABLE `women` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `url` text NOT NULL,
  `timestamp` varchar(30) NOT NULL,
  `ip` varchar(30) NOT NULL,
  `agent` varchar(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;

--
-- Data for Table `women`
--

/*!40000 ALTER TABLE `women` DISABLE KEYS */;
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('1','https://cdn.filestackcontent.com/P0JgjV35RcuPDbczYotr','1457431884','123.238.21.18, 162.158.50.4','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('2','https://cdn.filestackcontent.com/mno4HsL9Q9qHUGQU62xl','1457432431','123.238.21.18, 162.158.50.4','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('3','https://cdn.filestackcontent.com/XcivYstQAS8vlCB1xXOA','1457433166','123.238.21.18, 162.158.50.4','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('4','https://cdn.filepicker.io/api/file/CLhgGXYFSWSHqfwrJqWE','1457433472','123.238.21.18, 162.158.50.4','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('5','https://cdn.filepicker.io/api/file/8SGhrbAR4ueMAfEndUJe','1457433545','123.238.21.18, 162.158.50.4','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('6','https://cdn.filepicker.io/api/file/VSIWL7B5RgiZDcjYyzeK','1457433594','123.238.21.18, 162.158.50.4','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('7','https://cdn.filepicker.io/api/file/DjLYwClKStyltscX2xTT','1457440546','43.225.192.2, 162.158.50.4','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('8','https://cdn.filepicker.io/api/file/bBzi4SAYTea3MDXNfueI','1457440783','123.238.21.18, 162.158.50.4','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('9','https://cdn.filepicker.io/api/file/O7zHBJ5yQk6BUf4iRDKn','1457441602','123.238.21.18, 162.158.50.4','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('10','https://cdn.filepicker.io/api/file/LFqh0xOwSjO1fLEDHXr5','1457441642','111.125.141.114, 162.158.46.16','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('11','https://cdn.filepicker.io/api/file/e6cc0MWZS0CQleDxtekk','1457441734','111.125.141.114, 162.158.46.16','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('12','https://cdn.filepicker.io/api/file/svykvqcVTSWxoTKVjmbs','1457441881','111.125.141.114, 162.158.46.16','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('13','https://cdn.filepicker.io/api/file/3BnigaQNQOuSSQILp3q9','1457441884','103.37.201.84, 162.158.46.159','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('14','https://cdn.filepicker.io/api/file/EF9uGWRMRhqUZ46PwcQh','1457442090','43.225.192.2, 162.158.50.4','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('15','https://cdn.filepicker.io/api/file/PsHVtBfNTlmK3M86fJiq','1457442784','14.139.238.98, 162.158.47.125','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('16','https://cdn.filepicker.io/api/file/fkMLCZ24T2e4zagiEtYG','1457442798','120.56.202.254, 162.158.51.211','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('17','https://cdn.filepicker.io/api/file/fqw24KGCSp9YRAGHVM7A','1457442940','115.249.130.57, 162.158.50.13','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('18','https://cdn.filepicker.io/api/file/lSKZ9TJASPyiZWe3mGya','1457443091','59.178.206.43, 162.158.46.168','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('19','https://cdn.filepicker.io/api/file/1rwHFJhvQ4O7kuntjuIs','1457443300','120.59.234.167, 162.158.46.161','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('20','https://cdn.filepicker.io/api/file/OKcietxNSDOF3wmZOCqi','1457443707','49.32.12.191, 103.22.201.239','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('21','https://cdn.filepicker.io/api/file/5NeRyQORsiTTt9tNvO5Q','1457443918','93.159.134.30, 162.158.102.38','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('22','https://cdn.filepicker.io/api/file/UrWQjoTDS3cIlEok27gg','1457444065','122.176.252.2, 162.158.47.126','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('23','https://cdn.filepicker.io/api/file/p2z28XvsTcu9JvXSmQ77','1457444145','122.176.252.2, 162.158.47.126','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('24','https://cdn.filepicker.io/api/file/boYmzlyPTX2opgP7adAw','1457445316','59.178.168.98, 162.158.46.161','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('25','https://cdn.filepicker.io/api/file/pK3P6OY0SASf8e9S6UDJ','1457445905','223.238.177.201, 162.158.55.13','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('26','https://cdn.filepicker.io/api/file/koSlP8lZTHa5XTb8SxFw','1457446902','113.193.78.3, 162.158.51.203','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('27','https://cdn.filepicker.io/api/file/1MJuGMFeS4aFOmHSEaee','1457446999','113.193.78.3, 162.158.51.203','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('28','https://cdn.filepicker.io/api/file/zoaMxo0FSHuKSOEfILwC','1457447434','113.193.78.3, 162.158.51.203','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('29','https://cdn.filepicker.io/api/file/oqJ69Q1TRHa2wJnfv4GX','1457447489','113.193.78.3, 162.158.51.203','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('30','https://cdn.filepicker.io/api/file/nUpQkMB3SciNQmSlEyQA','1457447696','59.177.136.165, 162.158.46.168','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('31','https://cdn.filepicker.io/api/file/Ikz5nO0CQCrX50YiRb8i','1457448180','116.203.74.30, 162.158.47.126','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('32','https://cdn.filepicker.io/api/file/s9O8b9vT2WQCBdoqLmVL','1457449488','59.177.136.165, 162.158.51.209','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('33','https://cdn.filepicker.io/api/file/xIgTgEKBQWipXNaOWEZK','1457449507','1.23.98.214, 162.158.51.210','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('34','https://cdn.filepicker.io/api/file/nOCJcShvSvqiUcZm1Djk','1457449615','1.23.98.214, 162.158.51.210','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('35','https://cdn.filepicker.io/api/file/34Mlvft7SUKKuMi9w56N','1457450079','14.98.33.141, 162.158.50.12','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('36','https://cdn.filepicker.io/api/file/FVJyezpoRfqdASnkkQef','1457450158','1.39.33.172, 162.158.46.165','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('37','https://cdn.filepicker.io/api/file/fZ1CaUqRymk6LIevZERn','1457450212','72.181.126.197, 108.162.221.18','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('38','https://cdn.filepicker.io/api/file/eijHPlcTwKob3KRQJZFi','1457450216','182.69.69.206, 162.158.46.168','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('39','https://cdn.filepicker.io/api/file/oJoo8NF7Rf2lzpG4B7Ez','1457452156','72.181.126.197, 108.162.221.18','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('40','https://cdn.filepicker.io/api/file/YkpkZmIkSrmIUJTvOTnk','1457452685','72.181.126.197, 108.162.221.18','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('41','https://cdn.filepicker.io/api/file/H0my6b64St2PjRmdnh4A','1457452704','72.181.126.197, 108.162.221.18','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('42','https://cdn.filepicker.io/api/file/ystrNzqMQNmolevcrcc0','1457452765','106.198.105.219, 162.158.54.15','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('43','https://cdn.filepicker.io/api/file/Tpx06QRXSHOMRlTDaC05','1457452910','117.207.186.165, 162.158.50.12','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('44','https://cdn.filepicker.io/api/file/PafgI78GSvC5ceInjHqO','1457455330','123.238.21.18, 162.158.50.4','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('45','https://cdn.filepicker.io/api/file/4OzdSjyxTIG9ulCb1kTG','1457457169','125.99.184.54, 162.158.46.167','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('46','https://cdn.filepicker.io/api/file/0TmEcnxSNyF6hSr4hsZj','1457461453','59.178.158.83, 162.158.46.159','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('47','https://cdn.filepicker.io/api/file/9a1N1BXlRf29DtSPPpFE','1457461552','59.178.158.83, 162.158.46.159','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('48','https://cdn.filepicker.io/api/file/6j91op80S5a6M0Oe2kdv','1457461721','59.178.158.83, 162.158.46.159','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('49','https://cdn.filepicker.io/api/file/XyDao1QKS4y7DouVlqlQ','1457461836','59.178.158.83, 162.158.46.159','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('50','https://cdn.filepicker.io/api/file/dCVKFz6kSVyxVGDaVlDS','1457462638','59.178.158.83, 162.158.50.13','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('51','https://cdn.filepicker.io/api/file/MJGAounQmuexzzNekm26','1457462780','59.178.158.83, 162.158.50.13','1');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('52','https://cdn.filepicker.io/api/file/gkodFKvkRN34lyUXby5a','1457463395','117.96.43.73, 162.158.47.132','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('53','https://cdn.filepicker.io/api/file/7rJx9QpfRg6NIvpr6fWa','1457463580','117.96.43.73, 162.158.47.132','0');
INSERT INTO `women` (`id`,`url`,`timestamp`,`ip`,`agent`) VALUES ('54','https://cdn.filepicker.io/api/file/4kBzRKooT3emx7lMZZbY','1457535747','72.181.126.197, 108.162.221.18','1');
/*!40000 ALTER TABLE `women` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

